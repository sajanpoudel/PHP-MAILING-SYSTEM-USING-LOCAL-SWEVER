<?php 
	/*Update credentials*/
	define('EMAIL', 'Yor gmail');
	define('PASS', 'your gmail password');
 ?>